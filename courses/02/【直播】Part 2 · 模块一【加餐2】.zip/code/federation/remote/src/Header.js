import React from 'react'

class Header extends React.PureComponent {
  render() {
    return (
      <p>Remote应用当中的 header组件</p>
    )
  }
}

export default Header

