import { fn1 } from './m1'

console.log(fn1)

// 入口文件只是导了 m1 里的 fn1

// 此时我们站在入口文件上看， fn2 fn3 fn4 都没用

