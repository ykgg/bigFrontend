export function fn3() {
  console.log('fn3')
}

export function fn4() {
  console.log('fn4')
}