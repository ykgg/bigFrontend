import cryptoJs from 'crypto-js'
// crypto 
// buffer 
// stream 
console.log(cryptoJs.MD5('拉勾教育').toString())
/**
 * 此时我想使用一个第三方的加密工具包完成字符的加密操作
 */