import lgpng from './lg.png'
import lgico from './lg.ico'
import lgtxt from './lg.txt'
import lgjpg from './lg.jpg'

console.log('png---->', lgpng)
console.log('ico---->', lgico)
console.log('txt---->', lgtxt)
console.log('jpg---->', lgjpg)