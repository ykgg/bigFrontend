import React from 'react'
import ReactDOM from 'react-dom'

ReactDOM.render(<h1>今晚很开心1111111</h1>, document.getElementById('root'))