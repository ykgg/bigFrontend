console.log('b.js中的内容')

