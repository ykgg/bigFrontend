require('./a.js')
require('./lg/b.js')

console.log('index.js中的内容')


