require('./a')
require('./lg/b.js')

console.log('index.js')